let back_to_list_btn = document.getElementById("back_to_list_btn");
const back_to_list = () => {
    window.location.href = "../html/ver-hinchas.html";
};
back_to_list_btn.addEventListener("click", back_to_list);