# Tarea 1 Desarrollo de Aplicaciones Web

## Imagenes

- Todas las imagenes fueron sacadas por mí con recuerdos que tenía en mi pieza.

## ver-hinchas.html y ver-artesanos.html

- Al hacer click en el nombre de algún hincha o artesano, se mostrará informacion-artesano.html o informacion-hincha.html, según el listado en el cual se encuentre.

## informacion-artesano.hmtl

- La imagen se agranda y se achica al hacer click sobre ella.

## Sobre validaciones

- Para el número de teléfono es necesario añadir +569 al principio y el número puede ser recibido con espacios (+56 9 1234 5678) o sin espacios (+56912345678).

- Las fotos recibidas para el registro de artesanos pueden estar distribuidas de cualquier forma entre las 3 entradas de archivos.

## Lamentablemente me faltó tiempo para poder implementar más estilos en la tarea
