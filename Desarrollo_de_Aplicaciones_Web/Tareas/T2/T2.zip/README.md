# Consideraciones

- Solo alcancé a implementar el registro de artesanos.
- El listado de artesanos e información artesano siguen estáticos, pero las url están manejadas con Flask.