# Tarea 3 Desarrollo de Aplicaciones Web

## Registro de hinchas

- En caso de errores de validación de JavaScript o por el lado del servidor, aparecerán listados en un cuadro rojo.

## Listado de hinchas

- El listado está ordenado alfabéticamente por los nombres de los hinchas.
- Si no se especificó un número de teléfono, el campo aparecerá vacío en la tabla.

## Información de hinchas

- Las imágenes cambian de tamaño al hacer click sobre ellas.

## Gráficos

- Los gráficos fueron hechos con highcharts.
